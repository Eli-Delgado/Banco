package com.web.app.models_entitys;

public class AdminBanco {

	
	private Integer numClientes;
	private Integer numPrestamos;
	private float dineroBanco;
	
	
	public Integer getNumClientes() {
		return numClientes;
	}
	public void setNumClientes(Integer numClientes) {
		this.numClientes = numClientes;
	}
	public Integer getNumPrestamos() {
		return numPrestamos;
	}
	public void setNumPrestamos(Integer numPrestamos) {
		this.numPrestamos = numPrestamos;
	}
	public float getDineroBanco() {
		return dineroBanco;
	}
	public void setDineroBanco(float dineroBanco) {
		this.dineroBanco = dineroBanco;
	}
	
	
	
}
