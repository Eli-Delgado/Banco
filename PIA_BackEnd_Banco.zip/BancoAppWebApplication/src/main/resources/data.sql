insert into cliente (id_Cliente, nombre, telefono, correo, direccion, monto) values (1 , 'Eli', 8124 , 'eli.israel@outlook.com', 'Hermanos Larralde no. 308', 1000);
insert into cliente (id_Cliente, nombre, telefono, correo, direccion, monto) values (2 , 'Fracisco', 7441 , 'paco.martinez@outlook.com', 'Jazmin 117', 20000);
insert into cliente (id_Cliente, nombre, telefono, correo, direccion, monto) values (3 , 'Kevin', 8124 , 'kevin.boyka@outlook.com', 'Zochimilco 203', 1000000);
insert into prestamo (id_Prestamo, monto, fecha_Creacion, fecha_Expiracion, tipo_Prestamo, id_Cliente) values (1, 100,'1/01/2020','2/12/2020', 1, 1);
insert into prestamo (id_Prestamo, monto, fecha_Creacion, fecha_Expiracion, tipo_Prestamo, id_Cliente) values (2, 200,'3/01/2020','4/12/2020', 1, 2);
insert into prestamo (id_Prestamo, monto, fecha_Creacion, fecha_Expiracion, tipo_Prestamo, id_Cliente) values (3, 300,'5/01/2020','6/12/2020', 1, 3);